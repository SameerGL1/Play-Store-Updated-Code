package com.hcl;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.config.server.EnableConfigServer;


@SpringBootApplication
@EnableConfigServer  //application is acting as a server
public class Week8Day1SpringCloudServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(Week8Day1SpringCloudServerApplication.class, args);
	}

}
