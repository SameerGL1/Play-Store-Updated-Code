package com.hcl;

import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
 
import java.util.ArrayList;
import java.util.List;
 
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
 
import com.hcl.controller.UserController;
import com.hcl.entities.LoginRequest;
import com.hcl.entities.Users;
import com.hcl.service.UserServiceImpl;
import com.hcl.util.JwtUtil;

@ExtendWith(MockitoExtension.class)
public class PlayStoreUserServiceApplicationTests {
	
    @Mock
    private UserServiceImpl userService;
    
    @Mock
    private JwtUtil jwtUtil;
    
    @InjectMocks
    private UserController userController;
    private Users testUser;
    private LoginRequest testLoginRequest;
    private List<Users> userList;
    
    @BeforeEach
    public void setUp() {
        testUser = new Users();
        testLoginRequest = new LoginRequest("testUsername", "testPassword");
        userList = new ArrayList<>();
        userList.add(testUser);
    }
    @Test
    public void testUserRegister_Success() {
        when(userService.getUserById(anyLong())).thenReturn(false);
        ResponseEntity<?> response = userController.userRegister(testUser);
        verify(userService, times(1)).userRegister(testUser);
        assert(response.getStatusCode()).equals(HttpStatus.CREATED);
    }
    @Test
    public void testUserRegister_AlreadyRegistered() {
        when(userService.getUserById(anyLong())).thenReturn(true);
        ResponseEntity<?> response = userController.userRegister(testUser);
        assert(response.getStatusCode()).equals(HttpStatus.BAD_REQUEST);
    }
    @Test
    public void testUserLogin_Success() {
        when(userService.getAllUsers()).thenReturn(userList);
        when(jwtUtil.generateToken(toString())).thenReturn("testToken");
        String response = userController.userLogin(testLoginRequest);
        assert(response.equals("testToken"));
    }
    @Test
    public void testUserLogin_InvalidCredentials() {
        when(userService.getAllUsers()).thenReturn(userList);
        LoginRequest invalidLoginRequest = new LoginRequest("invalidUsername", "invalidPassword");
        String response = userController.userLogin(invalidLoginRequest);
        assert(response.equals("Bad/Invalid Credentials Check And Try To Login Again"));
    }
    
}
