package com.hcl.exception;

public class UserAlreadyExistOrNotException extends Exception{
	public UserAlreadyExistOrNotException(String msg) {
		super(msg);
	}

}
