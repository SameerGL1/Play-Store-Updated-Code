package com.hcl.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.hcl.beans.Application;
import com.hcl.entities.UserFav;
import com.hcl.entities.Users;
import com.hcl.exception.UserAlreadyExistOrNotException;
import com.hcl.repository.UserFavRepository;
//import com.hcl.repository.AppRepository;
import com.hcl.repository.UserRepository;

@Service
public  class UserServiceImpl implements UserService{

	private UserRepository userRepo;
	private final RestTemplate restTemplate;
	private UserFavRepository userFavRepo;
	//private  AppRepository appRepo;
	
	@Autowired
	public UserServiceImpl(UserRepository userRepo,RestTemplate restTemplate,UserFavRepository userFavRepo) {
		//this.appRepo=appRepo;
		this.userRepo=userRepo;
		this.restTemplate = restTemplate;
		this.userFavRepo=userFavRepo;
	} 
	private final String ownerServiceUrl = "http://localhost:8084/api/owners";
	 
	
	@Override

	public Users userRegister(Users user) {

		//to register the owner

		return userRepo.save(user);

	}
	@Override
	public boolean getUserById(Long userId) {
		// TODO Auto-generated method stub
		boolean flag=true;
		try
		{
			Users user=userRepo.findById( userId).orElse(null);
			if(user!=null)
			{	

				throw new UserAlreadyExistOrNotException("Already Exist So U can't Register Again");
			}
			else
			{

				flag= false;

			}
		}
		catch(UserAlreadyExistOrNotException e)
		{

			System.out.println(e.getMessage());

		}
		return flag;

	}
	@Override
	public List<Users> getAllUsers() {
		// TODO Auto-generated method stub
		return userRepo.findAll();
	}
	
	
	public String getAppByName(String appName) {
	     String appNamed = appName;
	        String url = ownerServiceUrl + "/app/byName?appName=" + appNamed;
	        try {
	         String res=restTemplate.getForObject(url, String.class);
	         System.out.println(res);
	            return res;
	        } catch (HttpClientErrorException.NotFound e) {
	            // Handle 404 Not Found error
	            return null;
	        } catch (RestClientException e) {
	            // Handle other types of exceptions
	            e.printStackTrace(); // Print or log the exception
	            return null;
	        }
	    }
	
	
	public List<String> getAppByCategory(String category) {
        String url = ownerServiceUrl + "/apps/byCategory?category=" + category;
        List<String> apps = restTemplate.getForObject(url, List.class);
        if (apps != null && !apps.isEmpty()) {
            return apps;
        } else {
            return Collections.singletonList("Application not found");
        }
    }
    
	
    public Application getAppDetails(String name) {
        String url = ownerServiceUrl + "/apps/application?name=" + name;
        return restTemplate.getForObject(url, Application.class);
    }
    
    public Application getAppById(Long appid) {
        String url = ownerServiceUrl + "/getAppById/details?appid=" + appid;
        return restTemplate.getForObject(url, Application.class);
    }
     
    
    
	@Override
	public void addApplicationToFavorites(Long userId, Long appId) {
		// TODO Auto-generated method stub
		UserFav userFav = new UserFav();
        userFav.setUserid(userId);
        userFav.setAppid(appId);
        userFavRepo.save(userFav);	
	}
	
	
	@Override
	public List<Application> findAppsByUserid(Long userId) {
		// TODO Auto-generated method stub
		List<UserFav> userFav = userFavRepo.findByUserid(userId);
		UserServiceImpl userService=UserServiceImpl.this;
		List<Application> favApps=new ArrayList<>();
		
		for(UserFav userfavs:userFav) {
			Long appId=userfavs.getAppid();
			Application app=userService.getAppById(appId);
			favApps.add(app);		
		}
        return favApps;
	}
	
	
	@Override
	public List<Long> getUserFavoriteappId(Long userId) {
		// TODO Auto-generated method stub
		List<Long> appIds = userFavRepo.getUserFavoriteappId(userId);
        return appIds;
	}
	
	
	
	}




	


	
	

	


