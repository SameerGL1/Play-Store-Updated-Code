package com.hcl.controller;

import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.hcl.beans.Application;
import com.hcl.entities.LoginRequest;
import com.hcl.entities.Users;
import com.hcl.service.UserServiceImpl;
import com.hcl.util.JwtUtil;
@RestController
@RequestMapping("/api/users")
public class UserController {	   
	   @Autowired
		private JwtUtil jwtUtil;
	   @Autowired
        private  UserServiceImpl userService;
	   @Value("${UserCredentials.userId}")
	   private Long userId;
	   @Value("${UserCredentials.username}")
	   private String username;
	   @Value("${UserCredentials.password}")
	   private String password;
	   
	   @GetMapping("/addUserCred")
	   public ResponseEntity<?> addUserCred(){
		  Users users=new Users(userId,username,password);
		  userService.userRegister(users);
		  return new ResponseEntity<>("Registered Successfully",HttpStatus.CREATED);
	   }
	   
	   //For User Registration
	   
	   @PostMapping("/register")
		public ResponseEntity<?> userRegister(@RequestBody Users user)
		{
			boolean flag=userService.getUserById(user.getUserId());
			if(flag==false)
			{
			userService.userRegister(user);
			return new ResponseEntity<>("Registered Successfully",HttpStatus.CREATED);
			}
			else
			{
				return new ResponseEntity<>("Already Registered",HttpStatus.BAD_REQUEST);
			}	
		}	
		//User Login
		@PostMapping("/login")
		public String userLogin(@RequestBody LoginRequest loginRequest )
		{
			List<Users> list = userService.getAllUsers();
			boolean flag=false;
			if(list==null)
			{
				return "OOPS!!There are no owners";
			}
			else
			{
				for(Users o:list)
				{
					if(loginRequest.getUserName().equals(o.getUsername()) && loginRequest.getPassWord().equals(o.getPassword()))
					{	
						flag=true;
						
						break;
					}
					else
					{
						flag=false;	
					}
				}
			}
			if(flag==true)
			{
				String token=jwtUtil.generateToken(loginRequest.getUserName());
				return token;
			}
			else
			{
				return "Bad/Invalid Credentials Check And Try To Login Again";
			}	
		}
		
		//Fetching an app by using appname
		@GetMapping("/app/byName")
	    public ResponseEntity<String> getAppByName(@RequestParam String appName) {
	        String app = userService.getAppByName(appName);
	        if (app != null) {
	            return ResponseEntity.ok(app);
	        } else {
	            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Application not found");
	        }
	    }
		
		//Fetching an app by category
		@GetMapping("/apps/byCategory")
	    public ResponseEntity<List<String>> getAppByCategory(@RequestParam String category) {
	        List<String> apps = userService.getAppByCategory(category);
	        if (!apps.isEmpty() && !apps.get(0).equals("Application not found")) {
	            return ResponseEntity.ok(apps);
	        } else {
	            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Collections.singletonList("Application not found"));
	        }
	    }
	    
		//Fetching app details 
	    @GetMapping("/apps/application")
	    public ResponseEntity<Application> getAppDetails(@RequestParam String name) {
	        Application app = userService.getAppDetails(name);
	        if (app != null) {
	            return ResponseEntity.ok(app);
	        } else {
	            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
	        }
	    }
	    
	    
	    @PostMapping("/addApp")
	    public ResponseEntity<String> addApplicationToFavorites(@RequestParam Long userId, @RequestParam Long appId) {
	        userService.addApplicationToFavorites(userId, appId);
	        return ResponseEntity.ok("FavoriteApp added SuccessFully!!");
	    }
	    
	    
	    @GetMapping("/getUserFav")
	    public ResponseEntity<List<Application>> getFavoriteAppList(@RequestParam Long userId) {
	        List<Application> userFav = userService.findAppsByUserid(userId);
	        if (userFav != null) {
	            return ResponseEntity.ok(userFav);
	        } else {
	            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
	        }
	    }
	    
	    
	    @GetMapping("/getUserFavAppIds")
	    public ResponseEntity<List<Long>> getFavoriteAppId(@RequestParam Long userId) {
	        List<Long> appids = userService.getUserFavoriteappId(userId);
	        if (appids != null) {
	            return ResponseEntity.ok(appids);
	        } else {
	            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
	        }
	    }
}