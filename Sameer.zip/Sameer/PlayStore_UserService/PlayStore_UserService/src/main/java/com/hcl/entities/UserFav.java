package com.hcl.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class UserFav {
	 @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long favid;
	 	private Long userid;
	 	private Long appid;
	 	
	 
		public Long getFavid() {
			return favid;
		}
		public void setFavid(Long favid) {
			this.favid = favid;
		}
		public Long getUserid() {
			return userid;
		}
		public void setUserid(Long userid) {
			this.userid = userid;
		}
		public Long getAppid() {
			return appid;
		}
		public void setAppid(Long appid) {
			this.appid = appid;
		}
			

}
