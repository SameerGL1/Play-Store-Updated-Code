package com.hcl.service;

import java.util.List;

import com.hcl.beans.Application;
import com.hcl.entities.UserFav;
import com.hcl.entities.Users;



public interface UserService {
	
	public boolean getUserById(Long userId);
    public Users userRegister(Users user);
    public List<Users> getAllUsers();
    
    public void addApplicationToFavorites(Long userId, Long appId); 
    public List<Long> getUserFavoriteappId(Long userId);
	public List<Application> findAppsByUserid(Long userId);
}