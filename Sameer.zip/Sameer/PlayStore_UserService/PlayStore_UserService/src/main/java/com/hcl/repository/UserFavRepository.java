package com.hcl.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.hcl.entities.UserFav;

@Repository
public interface UserFavRepository extends JpaRepository<UserFav,Long>{
	
	public List<UserFav> findByUserid(Long userId);
	
	@Query("Select uf.appid from UserFav uf where uf.userid=?1")
	 public List<Long> getUserFavoriteappId(Long userId);

}
