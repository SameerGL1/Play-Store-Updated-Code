package com.hcl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.hcl.controller.OwnerController;
import com.hcl.entities.Application;
import com.hcl.exception.AppNotFoundException;
import com.hcl.service.OwnerServiceImpl;

@SpringBootTest
@ExtendWith(MockitoExtension.class)
class PlayStoreOwnerServiceApplicationTests {

	@Mock
    private OwnerServiceImpl ownerService;
    @InjectMocks
    private OwnerController ownerController;


 @Test
    public void testUpdateApp() throws AppNotFoundException {
        Long id = 1L; // Provide a valid id
        Application updatedApp = new Application(); // Initialize updatedApp object as needed
        when(ownerService.updateApp(id, updatedApp)).thenReturn(updatedApp);
        ResponseEntity<Application> response = ownerController.updateApp(id, updatedApp);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(updatedApp, response.getBody());
    }
 @Test
    public void testDeleteApp() throws AppNotFoundException {
        Long id = 1L; // Provide a valid id
        ResponseEntity<Void> response = ownerController.deleteApp(id);
        assertEquals(HttpStatus.NO_CONTENT, response.getStatusCode());
    }
 
 @Test
    public void testAddApp() {
        Application app = new Application(); // Initialize app object as needed
        when(ownerService.addApp(app)).thenReturn(app);
 
        ResponseEntity<Application> response = ownerController.addApp(app);
 
        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertEquals(app, response.getBody());
    }
}
