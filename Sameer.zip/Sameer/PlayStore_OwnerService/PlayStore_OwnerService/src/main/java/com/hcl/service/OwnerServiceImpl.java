package com.hcl.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.apache.http.HttpStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import com.hcl.entities.Application;
import com.hcl.entities.Owner;
import com.hcl.exception.AppNotFoundException;
import com.hcl.exception.UserAlreadyExistOrNotException;
import com.hcl.repository.AppRepository;
import com.hcl.repository.OwnerRepository;

@Service
public class OwnerServiceImpl implements OwnerService{
	
	@Autowired
	OwnerRepository ownerRepo;
	
	@Autowired
	RestTemplate restTemplate;
	
	private AppRepository appRepository;
	
	@Autowired
	public OwnerServiceImpl(AppRepository appRepository) {
		this.appRepository=appRepository;
	}
	
	private final String userServiceUrl = "http://localhost:8085/api/users";
	
    @Override
    public Application updateApp(Long id, Application updatedApp) throws AppNotFoundException {
        Optional<Application> existingApp = appRepository.findById(id);
        if (existingApp.isPresent()) {
            updatedApp.setAppid(id);
            return appRepository.save(updatedApp);
        } else {
            throw new AppNotFoundException("App not found with id: " + id);
        }
    }
 
    @Override
    public void deleteApp(Long id) throws AppNotFoundException {
        Optional<Application> existingApp = appRepository.findById(id);
        if (existingApp.isPresent()) {
            appRepository.deleteById(id);
        } else {
            throw new AppNotFoundException("App not found with id: " + id);
        }
    }

	@Override
	public Application addApp(Application app) {
		// TODO Auto-generated method stub
		return appRepository.save(app);
	}
	
	@Override
	public List<Owner> getAllOwners() {
		//to get all the owners
		return ownerRepo.findAll();
	}
	
	@Override
		public boolean getOwnerById(Long long1) {
			// TO check and get the owner exist or not by id
			boolean flag=true;
			try
			{
				Owner owner=ownerRepo.findById(long1).orElse(null);
				if(owner!=null)
				{	
					throw new UserAlreadyExistOrNotException("Already Exist So U can't Register Again");
				}
				else
				{
					flag= false;
				}
			}
			catch(UserAlreadyExistOrNotException e)
			{
			 System.out.println(e.getMessage());
			}
			return flag;
		}
	
		@Override
		public Owner ownerRegister(Owner owner) {
			//to register the owner
			return ownerRepo.save(owner);
		}

	@Override
	public String getbyName(String appname) {
		// TODO Auto-generated method stub
		return appRepository.getbyName(appname);
	}

	@Override
	public List<String> getbyCategory(String category) {
		// TODO Auto-generated method stub
		return appRepository.getbyCategory(category);
	}

	@Override
	public Application getAppDetails(String name) {
		// TODO Auto-generated method stub
		return appRepository.getAppDetails(name);
	}

	@Override
	public Optional<Application> getAppById(Long appid) {
		// TODO Auto-generated method stub
		Optional<Application> apps=appRepository.findById(appid);
		return apps;
	}
	
	
	public List<String> getFavoriteAppId(Long userId) {
        String url = userServiceUrl + "/getUserFavAppIds?userId=" + userId;
           List<Long> appIds =  restTemplate.getForObject(url, List.class); 
           List<String> appNames = new ArrayList<String>();
           for(int i=0;i<appIds.size();i++) {
        	   String appName = appRepository.getAppNameById(appIds.get(i));
        	   appNames.add(appName);
           }
           return appNames;
        
    }

}
