package com.hcl;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

@SpringBootApplication
@EnableDiscoveryClient
@EnableWebMvc
public class PlayStoreOwnerServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(PlayStoreOwnerServiceApplication.class, args);
	}
	
	@Bean
	public RestTemplate getRestTemplate()
	{ 
	return new RestTemplate();
	 
	}


}
