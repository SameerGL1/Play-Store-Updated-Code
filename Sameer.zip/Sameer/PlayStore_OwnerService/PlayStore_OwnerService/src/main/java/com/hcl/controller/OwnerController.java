package com.hcl.controller;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.hcl.entities.Application;
import com.hcl.entities.LoginRequest;
import com.hcl.entities.Owner;
import com.hcl.exception.AppNotFoundException;
import com.hcl.service.OwnerServiceImpl;
import com.hcl.util.JwtUtil;

@RestController
@RequestMapping("/api/owners")
public class OwnerController {
	
	@Autowired
	private JwtUtil jwtUtil;
	private OwnerServiceImpl ownerService;
	@Autowired
	public OwnerController(OwnerServiceImpl ownerService) {
		this.ownerService=ownerService;
	}
	//registering owner
	@PostMapping("/register")
	public ResponseEntity<?> ownerRegister(@RequestBody Owner owner)
	{
		boolean flag=ownerService.getOwnerById(owner.getId());
		if(flag==false)
		{
		ownerService.ownerRegister(owner);
		return new ResponseEntity<>("Registered Successfully",HttpStatus.CREATED);
		}
		else
		{
			return new ResponseEntity<>("Already Registered",HttpStatus.BAD_REQUEST);
		}	
	}	
	//logging owner
	@PostMapping("/login")
	public String ownerLogin(@RequestBody LoginRequest loginRequest )
	{
		List<Owner> list = ownerService.getAllOwners();
		boolean flag=false;
		if(list==null)
		{
			return "OOPS!!There are no owners";
		}
		else
		{
			for(Owner o:list)
			{
				if(loginRequest.getUserName().equals(o.getUsername()) && loginRequest.getPassWord().equals(o.getPassword()))
				{	
					flag=true;
					
					break;
				}
				else
				{
					flag=false;	
				}
			}
		}
		if(flag==true)
		{
			String token=jwtUtil.generateToken(loginRequest.getUserName());
			return token;
		}
		else
		{
			return "Bad/Invalid Credentials Check And Try To Login Again";
		}	
	}
	//adding app
	@PostMapping("/addApps")
    public ResponseEntity<Application> addApp(@RequestBody Application app) {
        Application addedApp = ownerService.addApp(app);
        return ResponseEntity.status(HttpStatus.CREATED).body(addedApp);
    }
 
 //updating app
    @PutMapping("/apps/update/{id}")
    public ResponseEntity<Application> updateApp(@PathVariable Long id, @RequestBody Application updatedApp) {
        Application updated = null;
        try {
            updated = ownerService.updateApp(id, updatedApp);
        } catch (AppNotFoundException e) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(updated);
    }
 
    //deleting app
    @DeleteMapping("/deleteApps/{id}")
    public ResponseEntity<Void> deleteApp(@PathVariable Long id) {
        try {
			ownerService.deleteApp(id);
		} catch (AppNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        return ResponseEntity.noContent().build();
    }
 

    @GetMapping("/app/byName")
	public ResponseEntity<String> getAppByName(@RequestParam String appName) {
	String app =  ownerService.getbyName(appName);
	if (app != null) {
	return ResponseEntity.ok(app);
	} else {
	return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Application not found");

	}

	}
    
    
    @GetMapping("/apps/byCategory")
    public ResponseEntity<List<String>> getAppByCategory(@RequestParam String category) {
    List<String> apps = ownerService.getbyCategory(category);
    if (apps != null && !apps.isEmpty()) {
         return ResponseEntity.ok(apps);
      } else {
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Collections.singletonList("Application not found"));
      }
    }
    
    @GetMapping("/apps/application")
    public ResponseEntity<Application> getAppDetails(@RequestParam String name) {
    Application apps = ownerService.getAppDetails(name);
    System.out.println(apps.getAppname());
    if (apps != null) {
         return ResponseEntity.ok(apps);
      } else {
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
      }
    }  
    
    @GetMapping("/getAppById/details")
    public ResponseEntity<?> getAppById(@RequestParam Long appid){
    	Optional<Application> apps=ownerService.getAppById(appid);
    	return ResponseEntity.ok(apps);
    }
    
    @GetMapping("/userFavApps")
    public ResponseEntity<List<String>> getFavoriteAppId(@RequestParam Long userId){
    	List<String> apps=ownerService.getFavoriteAppId(userId);
    	return ResponseEntity.ok(apps);
    }
    
    
    
    
    
}
