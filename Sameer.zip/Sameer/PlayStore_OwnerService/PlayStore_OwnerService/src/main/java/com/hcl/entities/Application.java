package com.hcl.entities;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Application {
	
	 @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long appid;
	 	private String appname;
	 	private String category;
	 	private Float version;
	 	private String description;
	 	private LocalDate release_date;
	 	private boolean visibility;
	 	 	
		public Long getAppid() {
			return appid;
		}
		public void setAppid(Long appid) {
			this.appid = appid;
		}
		public String getAppname() {
			return appname;
		}
		public void setAppname(String appname) {
			this.appname = appname;
		}
		public String getCategory() {
			return category;
		}
		public void setCategory(String category) {
			this.category = category;
		}
		public Float getVersion() {
			return version;
		}
		public void setVersion(Float version) {
			this.version = version;
		}
		public String getDescription() {
			return description;
		}
		public void setDescription(String description) {
			this.description = description;
		}
		public LocalDate getRelease_date() {
			return release_date;
		}
		public void setRelease_date(LocalDate release_date) {
			this.release_date = release_date;
		}
		public boolean isVisibility() {
			return visibility;
		}
		public void setVisibility(boolean visibility) {
			this.visibility = visibility;
		}
		
}
