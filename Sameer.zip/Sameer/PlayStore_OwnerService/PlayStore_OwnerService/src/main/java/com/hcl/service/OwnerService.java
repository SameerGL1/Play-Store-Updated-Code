package com.hcl.service;

import java.util.List;
import java.util.Optional;

import com.hcl.entities.Application;
import com.hcl.entities.Owner;
import com.hcl.exception.AppNotFoundException;

public interface OwnerService {
	
	public Application addApp(Application app);
	 
    Application updateApp(Long id, Application updatedApp) throws AppNotFoundException ;
 
    void deleteApp(Long id)  throws AppNotFoundException;
    
    public List<Owner> getAllOwners();
    
    public boolean getOwnerById(Long ownerId);
    public Owner ownerRegister(Owner owner);
    
    public String getbyName(String appname);
    public List<String> getbyCategory(String category);
    public Application getAppDetails(String name);
    public Optional<Application> getAppById(Long appid);
    
   

}
